import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import {LoginComponent} from './login/login.component'
@NgModule({
  imports: [BrowserModule, MatCardModule, MatTableModule, MatFormFieldModule],
  declarations: [AppComponent,LoginComponent],
  bootstrap: [AppComponent],
})
export class AppModule {}
