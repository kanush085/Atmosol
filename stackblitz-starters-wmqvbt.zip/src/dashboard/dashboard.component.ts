import {Component} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {MatTableModule} from '@angular/material/table';

/**
 * @title Table with sticky columns
 */
@Component({
  selector: 'dashboard',
  styleUrls: ['dashboard.component.css'],
  templateUrl: 'dashboard.component.html',

})
export class TableStickyColumnsExample {
  displayedColumns = [
    'id',
    'name',
    'email',
    'star'
   
  ];
  dataSource = ELEMENT_DATA;
}

export interface PeriodicElement {
  id: number;
  name: string;
  email: string;
 
}

const ELEMENT_DATA: PeriodicElement[] = [
  {id: 1, name: 'Hydrogen', email: 'H@gmail.com'},
  {id: 2, name: 'Helium', email: 'He@gmail.com'},
  {id: 3, name: 'Lithium', email: 'Li@gmail.com'},
  {id: 4, name: 'Beryllium', email: 'Be@gmail.com'},
  {id: 5, name: 'Boron',email: 'B@gmail.com'},
  {id: 6, name: 'Carbon',  email: 'C@gmail.com'},
  {id: 7, name: 'Nitrogen',  email: 'N@gmail.com'},
  {id: 8, name: 'Oxygen', email: 'O@gmail.com'},
  {id: 9, name: 'Fluorine',  email: 'F@gmail.com'},
  {id: 10, name: 'Neon', email: 'Ne@gmail.com'},
];